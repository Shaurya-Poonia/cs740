Program should be in Octave.
Behaviour should be like that of provided rejection.m (except that we are
plotting a different function).  Number of points for the histogram should be a
parameter but should default to 1000.  Also report the amount of
wasted random numbers as a percentage on the standard output.
Program will be run like this
% octave q5.m
Wasted = 23%

