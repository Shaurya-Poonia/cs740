When run the program outputs some random permuatation, e.g. 
5 9 7 3
