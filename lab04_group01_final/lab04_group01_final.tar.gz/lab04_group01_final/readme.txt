Task 4
Group 1
___________________________________________________________________________
Name 		       Roll. No. 	      % Effort
Saurabh Jain		143050048	      100
Vivek Punia	  	143059005	      100
____________________________________________________________________________	

Honor Code :- The code we have written is completely implemented by us. We have taken help of references during implementation.

We haven’t used any late days yet. For this assignment, we will be using 2 late days.

References

	Implementation
	
	1) We have used this reference for monte carlo method used in Question 1.
	http://math.stackexchange.com/questions/1200443/evaluating-difficult-monte-carlo-integration-in-r
	
	2) We made an attempt to use PCA for 6th question. But there was a difficulty in reducing the covariance to lower dimensions. Finally we used the approach taught in class.
	https://www.cs.princeton.edu/picasso/mats/PCA-Tutorial-Intuition_jp.pdf
	
	3) For 5th question, we have taken help from sample simulation posted by the instructor.
	http://www.cse.iitb.ac.in/~sharat/current/cs740/notes/samplingSimulation/programs/rejection.m

	4) For generating points on ellipse in question 6.
	http://math.stackexchange.com/questions/22064/calculating-a-point-that-lies-on-an-ellipse-given-an-angle

	5) Octave documentation 
	
