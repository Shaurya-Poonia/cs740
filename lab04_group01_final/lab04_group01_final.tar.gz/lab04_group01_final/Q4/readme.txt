Program should be in Octave.
Behaviour should be like that of provided sinepdf.m (except that we are
plotting a p.m.f.  Number of points for the histogram should be a
parameter but should default to 1000
Program will be run like this
% octave q3.m

